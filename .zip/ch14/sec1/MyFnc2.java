package sec1;
@FunctionalInterface
public interface MyFnc2 {
	public void method2(int x);
} //Consumer Type