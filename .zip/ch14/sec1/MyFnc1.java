package sec1;
@FunctionalInterface
public interface MyFnc1 {
	public void method1();
} //Bulk Type