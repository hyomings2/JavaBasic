package sec1;
@FunctionalInterface
public interface MyFnc4 {
	public int method4(int x);
} 
//Function Type : 매개값을 타입변환하여 반환
//Operator Type : 매개값을 연산하여 반환
//Predicate Type : 매개값을 비교하여 true/false로 반환