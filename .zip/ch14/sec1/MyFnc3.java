package sec1;
@FunctionalInterface
public interface MyFnc3 {
	public int method3();
} //Supplier(Return) Type