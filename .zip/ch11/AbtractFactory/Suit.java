package AbtractFactory;

public class Suit {

}