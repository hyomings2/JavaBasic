package Behavioral.Strategy;

public class StrategyGun implements Strategy { 
	@Override
	public void runStrategy() { 
		System.out.println("탕! 타탕! 탕탕!"); 
	}
}