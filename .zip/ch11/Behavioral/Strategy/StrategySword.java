package Behavioral.Strategy;

public class StrategySword implements Strategy { 
	@Override 
	public void runStrategy() { 
		System.out.println("쳉.. 채쟁챙 챙챙"); 
	} 
}