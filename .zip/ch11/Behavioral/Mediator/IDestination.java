package Behavioral.Mediator;

public interface IDestination{ 
	public void receiveEvent(String from, String event); 
}
