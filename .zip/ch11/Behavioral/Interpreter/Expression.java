package Behavioral.Interpreter;
//Interpreter : 문법 규칙을 정의하고 해석하는 패턴
public interface Expression {
    boolean interpreter(String con);
}