package Behavioral.Command;
//Command : 요청을 캡슐화하여 여러 기능을 실행할 수 있는 패턴
public interface Command {
    public void execute();
}