package Behavioral.Command;
public interface ChristmasTree {
    String decorate();
}