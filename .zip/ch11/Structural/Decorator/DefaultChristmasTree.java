package Structural.Decorator;

public class DefaultChristmasTree implements ChristmasTree {
    @Override
    public String decorate() {
        return "Christmas tree";
    }
}