package Structural.Decorator;
//Decorator : 객체에 추가적인 기능을 유연하게 확장하는 패턴
public interface ChristmasTree {
    String decorate();
}