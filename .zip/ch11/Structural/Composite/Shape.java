package Structural.Composite;

public interface Shape {
    public void draw(String color);
}
