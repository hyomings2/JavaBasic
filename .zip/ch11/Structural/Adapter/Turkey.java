package Structural.Adapter;

public interface Turkey {
    public void gobble();
    public void fly();
}
