package Structural.Bridge;

public interface Color {
	public void applyColor();
}