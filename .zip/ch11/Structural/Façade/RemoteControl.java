package Structural.Façade;

public class RemoteControl {
    public void Turn_On() {
        System.out.println("TV를 켜다");
    }

    public void Turn_Off() {
        System.out.println("TV를 끄다");
    }
}