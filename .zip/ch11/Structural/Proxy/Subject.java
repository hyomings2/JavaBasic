package Structural.Proxy;

public interface Subject {
    void showName();

    void setName(String name);

    void complicatedWork();
}