package Structural.Proxy;

public interface Shape {
    void draw();
}