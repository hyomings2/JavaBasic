package sec1;

public class Cat extends Animal {
	
}