package sec1;

public class Dog extends Animal {

}
