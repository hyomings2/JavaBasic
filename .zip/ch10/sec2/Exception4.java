package sec2;

public class Exception4 {
	public static void main(String[] args) throws ClassNotFoundException {
		Class cla = Class.forName("java.lang.String3");
	}
}